
INSERT INTO operations (type, quantity, value, location, status, created_at)
VALUES ('PURCHASE', 100.50, 5000.00, 'Fazenda São Paulo', 'COMPLETED', CURRENT_TIMESTAMP);

INSERT INTO operations (type, quantity, value, location, status, created_at)
VALUES ('SALE', 50.25, 3000.00, 'Fazenda Rio Grande', 'COMPLETED', CURRENT_TIMESTAMP);