package com.example.agro.enums;

import lombok.Getter;

@Getter
public enum OperationType {
    PURCHASE("Compra"),
    SALE("Venda"),
    DRYING("Secagem"),
    FEED("Ração");

    private final String description;

    OperationType(String description) {
        this.description = description;
    }

}