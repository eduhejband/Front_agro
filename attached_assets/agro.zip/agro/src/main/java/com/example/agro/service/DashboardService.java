package com.example.agro.service;

import com.example.agro.dto.DashboardMetricsDTO;
import com.example.agro.enums.OperationStatus;
import com.example.agro.enums.OperationType;
import com.example.agro.repository.OperationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final OperationRepository operationRepository;

    public DashboardMetricsDTO getDashboardMetrics() {
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = today.atTime(LocalTime.MAX);

        // Calcula métricas principais
        BigDecimal totalInventory = calculateTotalInventory();
        BigDecimal monthlyProfit = calculateMonthlyProfit();
        BigDecimal operationalBalance = calculateOperationalBalance();

        // Contagem de operações
        long todayOperations = operationRepository.countByCreatedAtBetween(startOfDay, endOfDay);
        long pendingOperations = operationRepository.countByStatus(OperationStatus.PENDING);

        // Métricas de fluxo
        DashboardMetricsDTO.FlowMetricsDTO flowMetrics = calculateFlowMetrics();

        return DashboardMetricsDTO.builder()
                .totalInventory(totalInventory)
                .monthlyProfit(monthlyProfit)
                .operationalBalance(operationalBalance)
                .todayOperations((int) todayOperations)
                .pendingOperations((int) pendingOperations)
                .flow(flowMetrics)
                .build();
    }

    private BigDecimal calculateTotalInventory() {
        BigDecimal totalPurchases = operationRepository.sumQuantityByType(OperationType.PURCHASE)
                .orElse(BigDecimal.ZERO);
        BigDecimal totalSales = operationRepository.sumQuantityByType(OperationType.SALE)
                .orElse(BigDecimal.ZERO);
        return totalPurchases.subtract(totalSales);
    }

    private BigDecimal calculateMonthlyProfit() {
        LocalDate firstDayOfMonth = LocalDate.now().withDayOfMonth(1);
        LocalDateTime startOfMonth = firstDayOfMonth.atStartOfDay();
        LocalDateTime endOfMonth = LocalDateTime.now();

        BigDecimal revenue = operationRepository.sumValueByTypeAndDateRange(
                        OperationType.SALE, startOfMonth, endOfMonth)
                .orElse(BigDecimal.ZERO);

        BigDecimal costs = operationRepository.sumValueByTypeAndDateRange(
                        OperationType.PURCHASE, startOfMonth, endOfMonth)
                .orElse(BigDecimal.ZERO);

        return revenue.subtract(costs);
    }

    private BigDecimal calculateOperationalBalance() {
        BigDecimal totalIncome = operationRepository.sumValueByType(OperationType.SALE)
                .orElse(BigDecimal.ZERO);
        BigDecimal totalExpenses = operationRepository.sumValueByType(OperationType.PURCHASE)
                .orElse(BigDecimal.ZERO);
        return totalIncome.subtract(totalExpenses);
    }

    private DashboardMetricsDTO.FlowMetricsDTO calculateFlowMetrics() {
        BigDecimal purchase = operationRepository.sumValueByType(OperationType.PURCHASE)
                .orElse(BigDecimal.ZERO);
        BigDecimal sales = operationRepository.sumValueByType(OperationType.SALE)
                .orElse(BigDecimal.ZERO);

        // Você pode adicionar cálculos específicos para drying e feed se necessário
        BigDecimal drying = BigDecimal.ZERO; // Exemplo - ajuste conforme sua lógica
        BigDecimal feed = BigDecimal.ZERO;   // Exemplo - ajuste conforme sua lógica

        BigDecimal balance = sales.subtract(purchase);

        return DashboardMetricsDTO.FlowMetricsDTO.builder()
                .purchase(purchase)
                .sales(sales)
                .drying(drying)
                .feed(feed)
                .balance(balance)
                .build();
    }
}