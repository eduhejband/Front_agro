package com.example.agro.repository;

import com.example.agro.enums.OperationStatus;
import com.example.agro.enums.OperationType;
import com.example.agro.model.Operation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface OperationRepository extends JpaRepository<Operation, Long> {
    List<Operation> findAllByOrderByCreatedAtDesc();  // Método adicionado

    List<Operation> findByTypeOrderByCreatedAtDesc(OperationType type);

    List<Operation> findByCreatedAtBetweenOrderByCreatedAtDesc(
            LocalDateTime start,
            LocalDateTime end
    );

    @Query("SELECT SUM(o.quantity) FROM Operation o WHERE o.type = :type")
    Optional<BigDecimal> sumQuantityByType(OperationType type);

    @Query("SELECT SUM(o.value) FROM Operation o WHERE o.type = :type")
    Optional<BigDecimal> sumValueByType(OperationType type);

    @Query("SELECT SUM(o.value) FROM Operation o WHERE o.type = :type AND o.createdAt BETWEEN :start AND :end")
    Optional<BigDecimal> sumValueByTypeAndDateRange(OperationType type, LocalDateTime start, LocalDateTime end);

    long countByCreatedAtBetween(LocalDateTime start, LocalDateTime end);

    long countByStatus(OperationStatus status);
}