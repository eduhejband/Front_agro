package com.example.agro.service;

import com.example.agro.dto.CreateOperationDTO;
import com.example.agro.dto.OperationDTO;
import com.example.agro.enums.OperationType;
import com.example.agro.model.Operation;
import com.example.agro.repository.OperationRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class OperationService {

    private final OperationRepository operationRepository;

    @Transactional(readOnly = true)
    public List<OperationDTO> findAll() {
        return operationRepository.findAllByOrderByCreatedAtDesc()
                .stream()
                .map(this::toDTO)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<OperationDTO> findByType(OperationType type) {
        if (type == null) {
            throw new IllegalArgumentException("Tipo da operação não pode ser nulo");
        }

        return operationRepository.findByTypeOrderByCreatedAtDesc(type)
                .stream()
                .map(this::toDTO)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<OperationDTO> findByDateRange(LocalDate startDate, LocalDate endDate) {
        if (startDate == null || endDate == null) {
            throw new IllegalArgumentException("Datas não podem ser nulas");
        }

        if (startDate.isAfter(endDate)) {
            throw new IllegalArgumentException("Data inicial não pode ser após data final");
        }

        LocalDateTime start = startDate.atStartOfDay();
        LocalDateTime end = endDate.atTime(23, 59, 59);

        return operationRepository.findByCreatedAtBetweenOrderByCreatedAtDesc(start, end)
                .stream()
                .map(this::toDTO)
                .toList();
    }

    public OperationDTO create(CreateOperationDTO createDTO) {
        if (createDTO == null) {
            throw new IllegalArgumentException("DTO de criação não pode ser nulo");
        }

        Operation operation = Operation.builder()
                .type(createDTO.getType())
                .quantity(createDTO.getQuantity())
                .value(createDTO.getValue())
                .location(createDTO.getLocation())
                .status(createDTO.getStatus())
                .createdAt(LocalDateTime.now())
                .build();

        Operation saved = operationRepository.save(operation);
        return toDTO(saved);
    }

    public OperationDTO update(Long id, CreateOperationDTO updateDTO) {
        if (id == null || updateDTO == null) {
            throw new IllegalArgumentException("ID ou DTO não podem ser nulos");
        }

        Operation operation = operationRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Operação não encontrada com ID: " + id));

        operation.setType(updateDTO.getType());
        operation.setQuantity(updateDTO.getQuantity());
        operation.setValue(updateDTO.getValue());
        operation.setLocation(updateDTO.getLocation());
        operation.setStatus(updateDTO.getStatus());

        Operation updated = operationRepository.save(operation);
        return toDTO(updated);
    }

    public void delete(Long id) {
        if (id == null) {
            throw new IllegalArgumentException("ID não pode ser nulo");
        }

        if (!operationRepository.existsById(id)) {
            throw new EntityNotFoundException("Operação não encontrada com ID: " + id);
        }

        operationRepository.deleteById(id);
    }

    private OperationDTO toDTO(Operation operation) {
        return OperationDTO.builder()
                .id(operation.getId())
                .type(operation.getType())
                .quantity(operation.getQuantity())
                .value(operation.getValue())
                .location(operation.getLocation())
                .status(operation.getStatus())
                .createdAt(operation.getCreatedAt())
                .build();
    }
}