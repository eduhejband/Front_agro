package com.example.agro.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DashboardMetricsDTO {
    private BigDecimal totalInventory;
    private BigDecimal monthlyProfit;
    private BigDecimal operationalBalance;
    private Integer todayOperations;
    private Integer pendingOperations;
    private FlowMetricsDTO flow;

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class FlowMetricsDTO {
        private BigDecimal purchase;
        private BigDecimal sales;
        private BigDecimal drying;
        private BigDecimal feed;
        private BigDecimal balance;
    }
}