package com.example.agro.enums;

import lombok.Getter;

@Getter
public enum OperationStatus {
    COMPLETED("Concluído"),
    PENDING("Pendente"),
    IN_PROGRESS("Em Andamento");

    private final String description;

    OperationStatus(String description) {
        this.description = description;
    }

}
