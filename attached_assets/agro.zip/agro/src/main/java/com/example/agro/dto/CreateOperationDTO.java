package com.example.agro.dto;

import com.example.agro.enums.OperationStatus;
import com.example.agro.enums.OperationType;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreateOperationDTO {

    @NotNull(message = "Tipo da operação é obrigatório")
    private OperationType type;

    @NotNull(message = "Quantidade é obrigatória")
    @DecimalMin(value = "0.01", message = "Quantidade deve ser maior que zero")
    @Digits(integer = 8, fraction = 2, message = "Quantidade deve ter no máximo 8 dígitos inteiros e 2 decimais")
    private BigDecimal quantity;

    @NotNull(message = "Valor é obrigatório")
    @DecimalMin(value = "0.01", message = "Valor deve ser maior que zero")
    @Digits(integer = 10, fraction = 2, message = "Valor deve ter no máximo 10 dígitos inteiros e 2 decimais")
    private BigDecimal value;

    @NotBlank(message = "Localização é obrigatória")
    @Size(max = 255, message = "Localização deve ter no máximo 255 caracteres")
    private String location;

    @Builder.Default
    private OperationStatus status = OperationStatus.COMPLETED;
}