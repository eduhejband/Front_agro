package com.example.agro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgroApplicationTests {

	@Test
	void contextLoads() {
	}

}
